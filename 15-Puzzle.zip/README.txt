Use WASD/Arrows to move the tile in that relative direction to the empty space.
Alternatively, click it with the mouse.
Pressing R would reroll numbered and empty arrangement on the board, while adding Shift would reroll walls too.
Use space to reopen the generation menu.