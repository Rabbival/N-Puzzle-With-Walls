Use WASD/Arrows to move the tile in that relative direction to the empty space.
Alternatively, click it with the mouse.
Pressing R would reset the board with a (very much probably) new configuration.