Try and get the numbers in the correct order, starting on the top left corner by rows.
Use WASD/Arrows to move the empty spaces around.
Alternatively, click the tile you'd like to move into the empty space with the mouse.

Pressing R would reroll numbered and empty arrangement on the board, while adding Shift would reroll walls too.
Use space to reopen the generation menu, Shift+ESC to close the app.
Pressing ESC when a pop-up message appears would close it, Enter would confirm it when the confirm button is visible.
Arrow keys may also be used for navigating the Loader screen.

Enjoy!